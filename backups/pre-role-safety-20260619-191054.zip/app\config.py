from functools import lru_cache
from pathlib import Path
from pydantic import BaseModel
import os


class Settings(BaseModel):
    app_name: str = "AI Cost Optimization Middleware"
    database_path: str = os.getenv("DATABASE_PATH", "data/app.sqlite3")
    request_size_limit_bytes: int = int(os.getenv("REQUEST_SIZE_LIMIT_BYTES", "1000000"))
    cors_origins: list[str] = ["*"]
    gemini_api_key: str | None = os.getenv("GEMINI_API_KEY")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    default_provider: str = "gemini"
    dry_run_warning: str = (
        "Dry-run validates middleware mechanics only. It does not prove real model output quality."
    )

    @property
    def project_root(self) -> Path:
        return Path(__file__).resolve().parents[1]


@lru_cache
def get_settings() -> Settings:
    return Settings()

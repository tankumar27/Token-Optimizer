from app.models import ChatMessage
from optimizer.cheap_layer import cheap_layer_backend, run_self_checks, canonical_fact_keys
from optimizer.pipeline import optimize_messages


def test_cheap_layer_self_checks_pass():
    assert run_self_checks() == []


def test_cheap_layer_removes_exact_duplicate_sentences():
    text = "Do not promise refund approval. Do not promise refund approval. Inform the customer that the request is under review."
    output, traces = cheap_layer_backend(text, "balanced")
    assert output.count("Do not promise refund approval.") == 1
    assert traces[0]["accepted"]
    assert traces[0]["surface_changes"]


def test_cheap_layer_detects_number_word_equivalent_metrics():
    text = (
        "Database write latency increased from 12 ms to 28 ms. "
        "Database write latency increased from twelve ms to twenty-eight ms."
    )
    output, traces = cheap_layer_backend(text, "balanced")
    assert traces[0]["accepted"]
    assert output in {
        "Database write latency increased from 12 ms to 28 ms.",
        "Database write latency increased from twelve ms to twenty-eight ms.",
    }
    assert canonical_fact_keys(text) == canonical_fact_keys(output)


def test_pipeline_compresses_numeric_surface_equivalents():
    text = (
        "Migration reached 84%. "
        "Migration reached eighty-four percent. "
        "Latency decreased from 720 ms to 290 ms. "
        "Latency decreased from seven hundred twenty ms to two hundred ninety ms."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert result["optimized_tokens"] < result["original_tokens"]
    assert output.count("Migration reached") == 1
    assert output.count("Latency decreased") == 1
    assert "84%" in output
    assert "720 ms" in output
    assert "290 ms" in output


def test_cheap_layer_compresses_repeated_entity_frames():
    text = (
        "Retrieved Context Chunk 1:\n"
        "Cohort NA-A was affected. Cohort EU-B was affected. Cohort APAC-C was affected. "
        "Cell cl-01 was affected. Cell cl-02 was affected. "
        "Biomarker IL-6 status is healthy. Biomarker TNF-alpha status is healthy."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert "Affected cohorts: NA-A, EU-B, and APAC-C." in output
    assert "Affected cells: cl-01 and cl-02." in output
    assert "Healthy biomarkers: IL-6 and TNF-alpha." in output


def test_cheap_layer_compresses_negative_safety_frames_without_ambiguity():
    text = (
        "No patient records were deleted. No patient records were corrupted. "
        "No patient records were exposed. Patient records were not exposed. "
        "Service GENOMIC-CACHE is not offline. Service GENOMIC-CACHE is not disabled."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert "No patient records were deleted, corrupted, or exposed." in output
    assert "Service GENOMIC-CACHE is not offline and is not disabled." in output
    assert "No Service GENOMIC-CACHE is offline" not in output


def test_cheap_layer_compresses_airline_operations_frames():
    text = (
        "Retrieved Context Chunk 1:\n"
        "Airport ORD was affected. Airport JFK was affected. Airport LAX was affected. "
        "Gate B-17 was affected. Gate C-04 was affected. "
        "Flight AA-217 is operational. Flight UA-442 is operational. "
        "Passenger PAX-0041 baggage was recovered. Passenger PAX-0042 baggage was recovered. "
        "Baggage BAG-7712 was recovered. Baggage BAG-7713 was recovered. "
        "Ops logged 41 baggage-delay complaints. Ops logged forty-one baggage delay complaints."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert "Affected airports: ORD, JFK, and LAX." in output
    assert "Affected gates: B-17 and C-04." in output
    assert "Operational flights: AA-217 and UA-442." in output
    assert "Recovered passenger baggage: PAX-0041 and PAX-0042." in output
    assert "Recovered baggage IDs: BAG-7712 and BAG-7713." in output
    assert output.count("Ops logged") == 1


def test_progress_events_with_same_value_are_not_merged():
    text = (
        "Recovery reached 79%. "
        "Recovery reached seventy-nine percent. "
        "Recovery paused at 79%. "
        "Recovery paused at seventy-nine percent."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert output.count("Recovery reached 79%.") == 1
    assert output.count("Recovery paused at 79%.") == 1


def test_repeated_frame_preserves_original_object_noun():
    text = (
        "Zone-A routing tables were migrated. "
        "Zone-B routing tables were migrated. "
        "Zone-C routing tables were migrated."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert output == "Zone-A, Zone-B, and Zone-C routing tables were migrated."
    assert "routing zones" not in output


def test_repeated_singular_conflict_warnings_become_one_plural_warning():
    text = (
        "Record A says service alpha is enabled but Record B says service alpha is disabled. "
        "Do not resolve this conflict. "
        "Invoice source says total is $40 but ledger source says total is $44. "
        "Do not resolve this conflict. "
        "Policy version one allows export, however policy version two prohibits export. "
        "Do not resolve this conflict."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert "service alpha is enabled" in output
    assert "ledger source says total is $44" in output
    assert "policy version two prohibits export" in output
    assert output.count("Do not resolve these conflicts.") == 1
    assert "Do not resolve this conflict." not in output


def test_conflict_warning_compression_preserves_section_boundaries():
    text = (
        "Retrieved Context Chunk 1:\n"
        "North source says quota is 10 but South source says quota is 12. Do not merge this contradiction. "
        "Primary log says job is complete but audit log says job is blocked. Do not merge this contradiction. "
        "Manual says access is allowed, however policy says access is denied. Do not merge this contradiction.\n\n"
        "Task:\n"
        "Do not merge this contradiction."
    )
    result = optimize_messages([ChatMessage(role="user", content=text)], "balanced", "dry-run", "dry-run")
    output = result["optimized_messages"][0].content
    assert result["quality_gate_status"]["accepted"]
    assert output.count("Do not merge these contradictions.") == 1
    assert "Task:\nDo not merge this contradiction." in output
    assert "quota is 10" in output and "quota is 12" in output


def test_cheap_layer_rejects_different_entities_with_same_state():
    text = "Region us-east-1 was affected. Region us-west-2 was affected."
    output, traces = cheap_layer_backend(text, "balanced")
    assert output == text
    assert not traces[0]["accepted"]


def test_cheap_layer_rejects_same_entity_different_states():
    text = "Service CACHE-WARMER is degraded. Service CACHE-WARMER is not offline."
    output, traces = cheap_layer_backend(text, "balanced")
    assert output == "Service CACHE-WARMER is degraded and is not offline."
    assert traces[0]["accepted"]


def test_cheap_layer_pipeline_handles_obvious_instruction_duplicates():
    result = optimize_messages(
        [ChatMessage(role="user", content="Agent Instructions:\nDo not promise refund approval.\nDo not promise refund approval.\nTask:\nWrite the response.")],
        "balanced",
        "dry-run",
        "dry-run",
    )
    output = result["optimized_messages"][0].content
    assert "cheap_layer" in result["backend_used"]
    assert output.count("Do not promise refund approval.") == 1
    assert "Task:\nWrite the response." in output
    assert "\n\nTask:" in output


def test_cheap_layer_audit_has_required_fields():
    _, traces = cheap_layer_backend("Please help. Please help.", "balanced")
    trace = traces[0]
    for key in [
        "version",
        "before",
        "after",
        "surface_changes",
        "semantic_removed",
        "rejected_removals",
        "validation_gate",
        "missing_protected_facts",
        "missing_state_signatures",
        "final_action",
    ]:
        assert key in trace

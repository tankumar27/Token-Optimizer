from __future__ import annotations

from dataclasses import dataclass, asdict
import re


@dataclass
class ProtectedRegion:
    placeholder: str
    value: str
    kind: str

    def to_dict(self) -> dict:
        data = asdict(self)
        data["length"] = len(self.value)
        data.pop("value", None)
        return data


PATTERNS: list[tuple[str, str]] = [
    ("fenced_code", r"```[\s\S]*?```"),
    ("inline_code", r"`[^`\n]+`"),
    ("latex", r"\$[^$\n]+\$"),
    ("json_block", r"(?s)(\{(?:[^{}]|(?:\{[^{}]*\}))*\}|\[(?:[^\[\]]|(?:\[[^\[\]]*\]))*\])"),
    ("xml_html", r"<[A-Za-z][^>]*>[\s\S]*?</[A-Za-z][^>]*>"),
    ("url", r"https?://[^\s)>\"]+"),
    ("email", r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    ("api_key_like", r"\b(?:sk-|AIza|AQ\.)[A-Za-z0-9_\-.]{16,}\b"),
    ("date", r"\b\d{4}-\d{2}-\d{2}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]* \d{1,2}, \d{4}\b"),
    ("money", r"\$\d[\d,]*(?:\.\d+)?\b"),
    ("percentage", r"\b\d+(?:\.\d+)?%"),
    ("percentage", r"\b(?:\d+(?:\.\d+)?|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)(?:[-\s]+(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand))*\s+percent\b"),
    ("legal_clause", r"\bClause \d+(?:\.\d+)*\b"),
    ("id", r"(?-i:\b[A-Z]{2,}(?:-[A-Z0-9]+)+\b)"),
    ("quoted_text", r"\"[^\"\n]{2,}\"|'[^'\n]{2,}'"),
    ("equation", r"\b[a-zA-Z]\s*(?:\([a-zA-Z]\))?\s*=\s*[-+*/^(). 0-9a-zA-Z]+\b"),
]


def _protect_matches(text: str, kind: str, pattern: str, regions: list[ProtectedRegion], seen: dict[tuple[str, str], str]) -> str:
    def replace(match: re.Match) -> str:
        value = match.group(0)
        if value.startswith("__PROTECTED_"):
            return value
        key = _canonical_protected_key(kind, value)
        if key in seen:
            return seen[key]
        placeholder = f"__PROTECTED_{len(regions)}__"
        seen[key] = placeholder
        regions.append(ProtectedRegion(placeholder, value, kind))
        return placeholder

    return re.sub(pattern, replace, text, flags=re.IGNORECASE)


NUMBER_WORDS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
    "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
    "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
    "eighteen": 18, "nineteen": 19, "twenty": 20, "thirty": 30,
    "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
    "eighty": 80, "ninety": 90, "hundred": 100, "thousand": 1000,
}


def _canonical_protected_key(kind: str, value: str) -> tuple[str, str]:
    low = value.lower().replace(",", "").strip()
    if kind == "percentage":
        raw = low[:-1] if low.endswith("%") else re.sub(r"\s+percent$", "", low)
        return kind, _normalize_number(raw)
    if kind == "measurement":
        match = re.fullmatch(r"(.+?)\s*(ms|milliseconds|seconds|minutes|hours|days)", low)
        if match:
            unit = match.group(2)
            unit = "ms" if unit in {"ms", "milliseconds"} else unit.rstrip("s")
            return kind, f"{_normalize_number(match.group(1))}:{unit}"
    return kind, value


def _normalize_number(value: str) -> str:
    parsed = _parse_number_words(value)
    if parsed is not None:
        return str(parsed)
    return value.strip()


def _parse_number_words(text: str) -> int | None:
    parts = [part for part in re.split(r"[-\s]+", text.lower().strip()) if part]
    if not parts or any(part not in NUMBER_WORDS for part in parts):
        return None
    total = 0
    current = 0
    for part in parts:
        value = NUMBER_WORDS[part]
        if part == "hundred":
            current = max(1, current) * 100
        elif part == "thousand":
            total += max(1, current) * 1000
            current = 0
        else:
            current += value
    return total + current


def protect_text(text: str) -> tuple[str, list[ProtectedRegion]]:
    regions: list[ProtectedRegion] = []
    seen: dict[tuple[str, str], str] = {}
    protected = text
    for kind, pattern in PATTERNS:
        protected = _protect_matches(protected, kind, pattern, regions, seen)
    return protected, regions


def restore_text(text: str, regions: list[ProtectedRegion]) -> str:
    restored = text
    for region in regions:
        restored = restored.replace(region.placeholder, region.value)
    return restored


def protected_regions_preserved(restored_text: str, regions: list[ProtectedRegion]) -> bool:
    return all(region.value in restored_text for region in regions)


def public_region_metadata(regions: list[ProtectedRegion]) -> list[dict]:
    return [region.to_dict() for region in regions]


def extract_sensitive_facts(text: str) -> dict[str, set[str]]:
    facts: dict[str, set[str]] = {}
    for kind, pattern in PATTERNS:
        if kind in {"fenced_code", "inline_code", "json_block", "xml_html", "quoted_text"}:
            continue
        facts.setdefault(kind, set()).update(re.findall(pattern, text, flags=re.IGNORECASE))
    number_text = re.sub(
        r"(?im)^(?:Retrieved (?:context|contract) chunk|Source|Chunk|Document section)\s+[A-Z0-9]+(?:\s*[-\u2013\u2014?]\s*[^:]+)?:.*$",
        "",
        text,
    )
    number_text = re.sub(
        r"(?im)^(?:User Question|Question|Task|System Prompt|Instructions|Metadata|Customer Ticket):.*$",
        "",
        number_text,
    )
    facts["number"] = set(re.findall(r"\b\d+(?:\.\d+)?\b", number_text))
    return facts

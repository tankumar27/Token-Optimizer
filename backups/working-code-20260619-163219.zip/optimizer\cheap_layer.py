from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, asdict
from difflib import SequenceMatcher
import re

from .semantic_validator import SemanticValidator
from .token_counter import count_tokens


VERSION = "cheap_layer_v1_2026_06_19"
BACKEND_NAME = "cheap_layer"


NUMBER_WORDS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40,
    "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
    "hundred": 100, "thousand": 1000,
}
NUMBER_WORD_RE = r"(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)(?:[-\s]+(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand)){0,7}"

RISK_MARKERS = {
    "not", "no", "never", "cannot", "can't", "must not", "should not", "do not",
    "however", "but", "except", "unless", "denied", "restricted", "prohibited",
    "failed", "failure", "pending", "blocked", "degraded", "offline", "inactive",
    "read-only", "unavailable", "secret", "credential", "confidential",
}

STATE_WORDS = {
    "degraded", "offline", "inactive", "read-only", "unavailable", "pending",
    "approved", "denied", "retained", "deleted", "disabled", "enabled",
}

HEADER_RE = re.compile(
    r"(?im)^((?:Retrieved\s+Context\s+Chunk|Chunk|Source|Document)\s+[A-Z0-9]+(?:\s*[-\u2013\u2014?]\s*[^:]{1,100})?|"
    r"Task|User Question|Customer Question|Customer Ticket|Ticket|Agent Instructions|Agent Reminder|"
    r"Clinical Operations Instructions|User Request|Business Question|Internal Instructions|System Instructions|"
    r"Developer Instructions|Support Instructions|Policy excerpt):\s*$"
)


@dataclass
class Section:
    label: str
    body: str
    kind: str


def cheap_layer_backend(text: str, level: str = "balanced") -> tuple[str, list[dict]]:
    compressor = CheapLayerCompressor()
    return compressor.compress(text, level)


class CheapLayerCompressor:
    def __init__(self, validator: SemanticValidator | None = None) -> None:
        # Keep the cheap layer actually cheap. Transformer-backed validation is
        # reserved for downstream semantic compression; this layer only removes
        # redundancy when lexical/fact anchors make equivalence obvious.
        self.validator = validator

    def compress(self, text: str, level: str = "balanced") -> tuple[str, list[dict]]:
        before = analyze_text(text)
        sections = parse_sections(text)
        rebuilt: list[str] = []
        surface_changes: list[dict] = []
        semantic_removed: list[dict] = []
        rejected: list[dict] = []

        for section in sections:
            sentences = split_sentences(section.body)
            if section.kind == "variable":
                body = section.body.strip()
            else:
                deduped, conflict_warning_changes = conflict_scope_warning_compress(sentences, section.label)
                surface_changes.extend(conflict_warning_changes)
                sentences = deduped
                deduped, changes = exact_dedupe_sentences(sentences, section.label)
                surface_changes.extend(changes)
                deduped, subsumption_changes = subsumed_sentence_compress(deduped, section.label)
                surface_changes.extend(subsumption_changes)
                deduped, frame_changes = frame_compress_sentences(deduped, section.label)
                surface_changes.extend(frame_changes)
                deduped, status_changes = same_subject_status_compress(deduped, section.label)
                surface_changes.extend(status_changes)
                deduped, negative_changes = negative_frame_list_compress(deduped, section.label)
                surface_changes.extend(negative_changes)
                deduped, list_changes = repeated_frame_list_compress(deduped, section.label)
                surface_changes.extend(list_changes)
                deduped, removed, rejected_pairs = self.semantic_dedupe_sentences(deduped, section.label, level)
                semantic_removed.extend(removed)
                rejected.extend(rejected_pairs)
                body = " ".join(deduped).strip()
            if body:
                rebuilt.append(render_section(section, body, len(sections)))

        compressed = "\n\n".join(part for part in rebuilt if part).strip()
        compressed = re.sub(r"[ \t]+\n", "\n", compressed)
        compressed = re.sub(r"\n{3,}", "\n\n", compressed)
        gate = validation_gate(text, compressed)
        after = analyze_text(compressed) if gate["passed"] else before
        if not gate["passed"] or after["tokens"] >= before["tokens"]:
            trace = self._trace(text, text, before, before, [], [], rejected, gate, "cheap layer rejected or no token savings", False)
            return text, [trace]
        trace = self._trace(text, compressed, before, after, surface_changes, semantic_removed, rejected, gate, "cheap layer accepted", True)
        return compressed, [trace]

    def semantic_dedupe_sentences(self, sentences: list[str], label: str, level: str) -> tuple[list[str], list[dict], list[dict]]:
        if len(sentences) <= 1:
            return sentences, [], []
        thresholds = {"safe": 0.92, "balanced": 0.88, "aggressive": 0.84}
        threshold = thresholds.get(level, 0.88)
        removed: set[int] = set()
        accepted: list[dict] = []
        rejected: list[dict] = []
        pairs: list[tuple[float, int, int, float, float]] = []
        for i in range(len(sentences)):
            for j in range(i + 1, len(sentences)):
                lex = lexical_similarity(sentences[i], sentences[j])
                sem = self.validator.similarity(sentences[i], sentences[j])["semantic_similarity"] if self.validator else lex
                score = max(lex, 0.85 * sem + 0.15 * lex)
                left_facts = canonical_fact_keys(sentences[i])
                right_facts = canonical_fact_keys(sentences[j])
                if left_facts and left_facts == right_facts:
                    score = max(score, 0.95)
                elif sentence_key(sentences[i]) != sentence_key(sentences[j]):
                    # Cheap layer semantic removal is only allowed when facts anchor equivalence.
                    # Unanchored paraphrases go to the smarter downstream semantic layer.
                    continue
                pairs.append((score, i, j, sem, lex))
        for score, i, j, sem, lex in sorted(pairs, reverse=True):
            if i in removed or j in removed or score < threshold:
                continue
            keep_idx, remove_idx = choose_keeper_index(sentences, i, j)
            ok, reasons = can_remove_sentence(sentences[remove_idx], sentences[keep_idx])
            record = {
                "section_label": label,
                "removed_sentence": sentences[remove_idx],
                "kept_sentence": sentences[keep_idx],
                "semantic_similarity": round(sem, 3),
                "lexical_similarity": round(lex, 3),
                "combined_score": round(score, 3),
                "reason": "conservative semantic duplicate" if ok else "semantic duplicate rejected by safety firewall",
            }
            if ok:
                removed.add(remove_idx)
                accepted.append(record)
            else:
                record["rejected_reason"] = "; ".join(reasons)
                rejected.append(record)
        return [sentence for idx, sentence in enumerate(sentences) if idx not in removed], accepted, rejected

    def _trace(
        self,
        original: str,
        compressed: str,
        before: dict,
        after: dict,
        surface_changes: list[dict],
        semantic_removed: list[dict],
        rejected: list[dict],
        gate: dict,
        reason: str,
        accepted: bool,
    ) -> dict:
        return {
            "backend": BACKEND_NAME,
            "candidate_type": "cheap_layer_compression",
            "version": VERSION,
            "accepted": accepted,
            "reason": reason,
            "rejected_reason": None if accepted else reason,
            "span_text": original,
            "retained_span": compressed if accepted else None,
            "removed_span": original if accepted else None,
            "tokens_saved": max(0, before["tokens"] - after["tokens"]),
            "score": round((before["tokens"] - after["tokens"]) / max(1, before["tokens"]), 3),
            "before": before,
            "after": after,
            "surface_changes": surface_changes,
            "semantic_removed": semantic_removed,
            "rejected_removals": rejected,
            "validation_gate": gate,
            "missing_protected_facts": gate["missing_protected_fact_keys"],
            "missing_state_signatures": gate["missing_state_signatures"],
            "final_action": choose_final_action(before, after, accepted),
            "risk_flags": [] if accepted else [reason],
        }


def parse_sections(text: str) -> list[Section]:
    matches = list(HEADER_RE.finditer(text))
    if not matches:
        return [Section("FULL_PROMPT", text.strip(), "context")]
    sections: list[Section] = []
    if matches[0].start() > 0:
        preface = text[:matches[0].start()].strip()
        if preface:
            sections.append(Section("PREFACE", preface, "instruction"))
    for idx, match in enumerate(matches):
        label = match.group(1).strip()
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        if not body:
            continue
        low = label.lower()
        kind = "variable" if re.search(r"question|task|ticket|request", low) else "instruction" if re.search(r"instructions|reminder", low) else "context"
        sections.append(Section(label, body, kind))
    return sections


def render_section(section: Section, body: str, count: int) -> str:
    if section.label in {"FULL_PROMPT", "PREFACE"}:
        return body
    return f"{section.label}:\n{body.strip()}"


def split_sentences(text: str) -> list[str]:
    pieces = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [piece.strip() for piece in pieces if piece.strip()]


def exact_dedupe_sentences(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    seen: set[str] = set()
    kept: list[str] = []
    changes: list[dict] = []
    for sentence in sentences:
        key = sentence_key(sentence)
        if key in seen:
            changes.append({
                "type": "exact_sentence_duplicate",
                "section_label": label,
                "removed_sentence": sentence,
                "reason": "exact normalized duplicate sentence",
            })
            continue
        seen.add(key)
        kept.append(sentence)
    return kept, changes


CONFLICT_WARNING_RE = re.compile(
    r"^(?P<prefix>(?:Do not|Never)\s+(?:automatically\s+)?(?:resolve|merge|reconcile|collapse|dedupe|deduplicate|combine|erase|remove|ignore|hide)\s+)"
    r"(?P<det>this|that|the|a|an)\s+"
    r"(?P<noun>conflict|contradiction|discrepancy|mismatch|inconsistency)"
    r"(?P<suffix>[^.!?]*)(?P<punct>[.!?])$",
    re.I,
)

CONFLICT_SCOPE_RE = re.compile(
    r"\b(conflict|contradiction|contradicts?|discrepanc(?:y|ies)|mismatch(?:es)?|inconsisten(?:t|cy|cies)|"
    r"disagree(?:s|ment)?|differs?|versus|vs\.?|but|however|on the other hand)\b",
    re.I,
)


def conflict_scope_warning_compress(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    groups: dict[tuple[str, str, str], list[tuple[int, str, re.Match]]] = {}
    for idx, sentence in enumerate(sentences):
        match = CONFLICT_WARNING_RE.match(sentence.strip())
        if not match:
            continue
        key = (
            normalize_text(match.group("prefix")),
            match.group("noun").lower(),
            normalize_text(match.group("suffix")),
        )
        groups.setdefault(key, []).append((idx, sentence, match))

    replacements: dict[int, str] = {}
    consumed: set[int] = set()
    changes: list[dict] = []
    conflict_context = sum(1 for sentence in sentences if CONFLICT_SCOPE_RE.search(sentence) and not CONFLICT_WARNING_RE.match(sentence.strip()))
    for entries in groups.values():
        if len(entries) < 3:
            continue
        if conflict_context < 2:
            continue
        first_idx, _, first_match = entries[0]
        plural = _plural_conflict_noun(first_match.group("noun"))
        replacement = (
            f"{first_match.group('prefix')}these {plural}"
            f"{first_match.group('suffix')}{first_match.group('punct')}"
        )
        replacements[first_idx] = replacement
        consumed.update(idx for idx, _, _ in entries)
        consumed.remove(first_idx)
        changes.append({
            "type": "conflict_scope_warning_compression",
            "section_label": label,
            "removed_sentence": " ".join(sentence for _, sentence, _ in entries),
            "kept_sentence": replacement,
            "reason": "repeated singular contradiction warning scoped to multiple conflict records",
            "conflict_records_seen": conflict_context,
        })

    if not replacements:
        return sentences, []
    output: list[str] = []
    for idx, sentence in enumerate(sentences):
        if idx in replacements:
            output.append(replacements[idx])
        elif idx not in consumed:
            output.append(sentence)
    return output, changes


def _plural_conflict_noun(noun: str) -> str:
    low = noun.lower()
    if low == "discrepancy":
        return "discrepancies"
    if low == "inconsistency":
        return "inconsistencies"
    return low + "s"


def subsumed_sentence_compress(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    removed: set[int] = set()
    changes: list[dict] = []
    normalized = [normalize_text(sentence).rstrip(".") for sentence in sentences]
    for i, short in enumerate(normalized):
        if i in removed or len(short.split()) < 3:
            continue
        for j, long in enumerate(normalized):
            if i == j or j in removed:
                continue
            if long.startswith(short + " because") and can_remove_sentence(sentences[i], sentences[j])[0]:
                removed.add(i)
                changes.append({
                    "type": "subsumed_sentence_duplicate",
                    "section_label": label,
                    "removed_sentence": sentences[i],
                    "kept_sentence": sentences[j],
                    "reason": "short restatement subsumed by detailed because-clause",
                })
                break
    if not removed:
        return sentences, []
    return [sentence for idx, sentence in enumerate(sentences) if idx not in removed], changes


def frame_compress_sentences(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    # Conservative frame compression: "Agents must verify X. Agents must verify Y." -> one list.
    groups: dict[str, list[str]] = {}
    originals: dict[str, list[str]] = {}
    passthrough: list[str] = []
    for sentence in sentences:
        match = re.match(r"^(?P<prefix>Agents? must verify|Agents? should verify|Support agents must confirm)\s+(?P<item>.+?)[.]?$", sentence, re.I)
        if not match:
            passthrough.append(sentence)
            continue
        prefix = "Agents must verify"
        item = re.sub(r"^(the)\s+", "", match.group("item").strip(), flags=re.I)
        groups.setdefault(prefix, []).append(item)
        originals.setdefault(prefix, []).append(sentence)
    changes: list[dict] = []
    compressed: list[str] = []
    for prefix, items in groups.items():
        normalized_items = []
        for item in items:
            for part in re.split(r",\s*| and ", item):
                cleaned = part.strip(" .")
                if cleaned and cleaned not in normalized_items:
                    normalized_items.append(cleaned)
        if len(originals[prefix]) >= 2 or len(normalized_items) >= 2:
            sentence = f"{prefix} {join_list(normalized_items)}."
            compressed.append(sentence)
            changes.append({
                "type": "frame_list_compression",
                "section_label": label,
                "removed_sentence": " ".join(originals[prefix]),
                "kept_sentence": sentence,
                "reason": "shared sentence frame with listable items",
            })
        else:
            compressed.extend(originals[prefix])
    return passthrough + compressed, changes


FRAME_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r"^Cohort\s+(?P<item>.+?)\s+was affected[.]?$", re.I), "Affected cohorts", "list_colon"),
    (re.compile(r"^Cell\s+(?P<item>.+?)\s+was affected[.]?$", re.I), "Affected cells", "list_colon"),
    (re.compile(r"^Airport\s+(?P<item>.+?)\s+was affected[.]?$", re.I), "Affected airports", "list_colon"),
    (re.compile(r"^Gate\s+(?P<item>.+?)\s+was affected[.]?$", re.I), "Affected gates", "list_colon"),
    (re.compile(r"^(?P<item>Zone-[A-Z0-9-]+)\s+routing tables were migrated[.]?$", re.I), "routing tables were migrated", "suffix_predicate"),
    (re.compile(r"^(?P<item>Class-[A-Z0-9-]+)\s+seating records were migrated[.]?$", re.I), "Migrated seating classes", "list_colon"),
    (re.compile(r"^(?P<item>Class-[A-Z0-9-]+)\s+seating records were not migrated[.]?$", re.I), "Not-migrated seating classes", "list_colon"),
    (re.compile(r"^Flight\s+(?P<item>.+?)\s+is operational[.]?$", re.I), "Operational flights", "list_colon"),
    (re.compile(r"^Passenger\s+(?P<item>.+?)\s+baggage was recovered[.]?$", re.I), "Recovered passenger baggage", "list_colon"),
    (re.compile(r"^Baggage\s+(?P<item>.+?)\s+was recovered[.]?$", re.I), "Recovered baggage IDs", "list_colon"),
    (re.compile(r"^The\s+(?P<item>.+?)\s+note pool is excluded from migration[.]?$", re.I), "Excluded note pools", "list_colon"),
    (re.compile(r"^Biomarker\s+(?P<item>.+?)\s+status is healthy[.]?$", re.I), "Healthy biomarkers", "list_colon"),
    (re.compile(r"^Biomarker\s+(?P<item>.+?)\s+is healthy[.]?$", re.I), "Healthy biomarkers", "list_colon"),
    (re.compile(r"^Service\s+(?P<item>.+?)\s+is online[.]?$", re.I), "Online services", "list_colon"),
    (re.compile(r"^Drug\s+(?P<item>.+?)\s+is active[.]?$", re.I), "Active drugs", "list_colon"),
    (re.compile(r"^Approved\s+(?P<item>.+?)[.]?$", re.I), "Approved findings", "list_colon"),
]


def repeated_frame_list_compress(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    groups: dict[str, dict[str, object]] = {}
    consumed: set[int] = set()
    for idx, sentence in enumerate(sentences):
        for pattern, frame, render_mode in FRAME_PATTERNS:
            match = pattern.match(sentence.strip())
            if not match:
                continue
            item = match.group("item").strip(" .")
            if item:
                group = groups.setdefault(frame, {"render_mode": render_mode, "entries": []})
                group["entries"].append((idx, item, sentence))  # type: ignore[index, union-attr]
            break

    replacements: dict[int, str] = {}
    changes: list[dict] = []
    for frame, group in groups.items():
        entries = group["entries"]  # type: ignore[index]
        render_mode = group["render_mode"]  # type: ignore[index]
        items: list[str] = []
        originals: list[str] = []
        for idx, item, sentence in entries:
            originals.append(sentence)
            if item not in items:
                items.append(item)
        if len(items) < 2 or len(entries) < 2:
            continue
        first_idx = entries[0][0]
        replacement = f"{join_list(items)} {frame}." if render_mode == "suffix_predicate" else f"{frame}: {join_list(items)}."
        if count_tokens(replacement) >= sum(count_tokens(sentence) for _, _, sentence in entries):
            continue
        replacements[first_idx] = replacement
        consumed.update(idx for idx, _, _ in entries)
        consumed.remove(first_idx)
        changes.append({
            "type": "repeated_frame_list_compression",
            "section_label": label,
            "removed_sentence": " ".join(originals),
            "kept_sentence": replacement,
            "reason": "same predicate repeated across listable entities",
        })

    if not replacements:
        return sentences, []
    output: list[str] = []
    for idx, sentence in enumerate(sentences):
        if idx in replacements:
            output.append(replacements[idx])
        elif idx not in consumed:
            output.append(sentence)
    return output, changes


STATUS_PATTERN = re.compile(
    r"^(?P<subject>(?!Do not\b).+?)\s+"
    r"(?P<predicate>"
    r"is inactive|is active|is degraded|is not offline|is not disabled|is not deleted|"
    r"is read-only|status is unavailable|still exists|"
    r"were migrated|was migrated|were retained|was retained|were not deleted|was not deleted|were not migrated|was not migrated|"
    r"is pending|is not approved|is stale|is locked|is not ready|is blocked"
    r")[.]?$",
    re.I,
)


def same_subject_status_compress(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    groups: dict[str, list[tuple[int, str, str]]] = {}
    for idx, sentence in enumerate(sentences):
        match = STATUS_PATTERN.match(sentence.strip())
        if not match:
            continue
        subject = match.group("subject").strip()
        predicate = match.group("predicate").lower()
        groups.setdefault(normalize_text(subject), []).append((idx, subject, predicate))

    replacements: dict[int, str] = {}
    consumed: set[int] = set()
    changes: list[dict] = []
    for entries in groups.values():
        predicates: list[str] = []
        for _, _, predicate in entries:
            if predicate not in predicates:
                predicates.append(predicate)
        if len(predicates) < 2:
            continue
        first_idx, subject, _ = entries[0]
        replacement = f"{subject} {join_predicates(predicates)}."
        if count_tokens(replacement) >= sum(count_tokens(sentences[idx]) for idx, *_ in entries):
            continue
        replacements[first_idx] = replacement
        consumed.update(idx for idx, *_ in entries)
        consumed.remove(first_idx)
        changes.append({
            "type": "same_subject_status_compression",
            "section_label": label,
            "removed_sentence": " ".join(sentences[idx] for idx, *_ in entries),
            "kept_sentence": replacement,
            "reason": "same subject repeated with listable status predicates",
        })

    if not replacements:
        return sentences, []
    output: list[str] = []
    for idx, sentence in enumerate(sentences):
        if idx in replacements:
            output.append(replacements[idx])
        elif idx not in consumed:
            output.append(sentence)
    return output, changes


def negative_frame_list_compress(sentences: list[str], label: str) -> tuple[list[str], list[dict]]:
    groups: dict[str, list[tuple[int, str, str, str, str]]] = {}
    for idx, sentence in enumerate(sentences):
        stripped = sentence.strip()
        match = re.match(r"^No\s+(?P<subject>.+?)\s+(?P<aux>were|was|are|is)\s+(?P<state>[A-Za-z-]+)[.]?$", stripped, re.I)
        if match:
            subject = match.group("subject").strip()
            aux = match.group("aux").lower()
            state = match.group("state").lower()
            groups.setdefault(subject.lower(), []).append((idx, subject, aux, state, "no"))
            continue
        match = re.match(r"^(?P<subject>.+?)\s+(?P<aux>were|was|are|is)\s+not\s+(?P<state>[A-Za-z-]+)[.]?$", stripped, re.I)
        if match:
            subject = match.group("subject").strip()
            aux = match.group("aux").lower()
            state = match.group("state").lower()
            groups.setdefault(subject.lower(), []).append((idx, subject, aux, state, "not"))

    replacements: dict[int, str] = {}
    consumed: set[int] = set()
    changes: list[dict] = []
    for _, entries in groups.items():
        states: list[str] = []
        for _, _, _, state, _ in entries:
            if state not in states:
                states.append(state)
        if len(states) < 2 or len(entries) < 2:
            continue
        first_idx, subject, aux, _, _ = entries[0]
        modes = {mode for *_, mode in entries}
        if modes == {"not"}:
            replacement = f"{subject} {aux} not " + f" and {aux} not ".join(states) + "."
        else:
            replacement = f"No {subject} {aux} {join_or_list(states)}."
        if count_tokens(replacement) >= sum(count_tokens(sentences[idx]) for idx, *_ in entries):
            continue
        replacements[first_idx] = replacement
        consumed.update(idx for idx, *_ in entries)
        consumed.remove(first_idx)
        changes.append({
            "type": "negative_frame_list_compression",
            "section_label": label,
            "removed_sentence": " ".join(sentences[idx] for idx, *_ in entries),
            "kept_sentence": replacement,
            "reason": "same negative safety frame repeated across states",
        })

    if not replacements:
        return sentences, []
    output: list[str] = []
    for idx, sentence in enumerate(sentences):
        if idx in replacements:
            output.append(replacements[idx])
        elif idx not in consumed:
            output.append(sentence)
    return output, changes


def can_remove_sentence(removed: str, kept: str) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    removed_facts = canonical_fact_keys(removed)
    kept_facts = canonical_fact_keys(kept)
    if not removed_facts <= kept_facts:
        reasons.append("protected facts would be lost")
    removed_states = state_signatures(removed)
    kept_states = state_signatures(kept)
    if not removed_states <= kept_states:
        reasons.append("state signatures would be lost")
    removed_events = event_signatures(removed)
    kept_events = event_signatures(kept)
    if not removed_events <= kept_events:
        reasons.append("event signatures would be lost")
    removed_risks = risk_keys(removed)
    kept_risks = risk_keys(kept)
    if not removed_risks <= kept_risks:
        reasons.append("risk/negation markers would be lost")
    if identity_fact_keys(removed) and identity_fact_keys(removed) != identity_fact_keys(kept):
        reasons.append("different entity identities")
    return not reasons, reasons


def validation_gate(original: str, compressed: str) -> dict:
    original_facts = canonical_fact_keys(original)
    compressed_facts = canonical_fact_keys(compressed)
    original_states = state_signatures(original)
    compressed_states = state_signatures(compressed)
    original_events = event_signatures(original)
    compressed_events = event_signatures(compressed)
    original_risks = risk_keys(original)
    compressed_risks = risk_keys(compressed)
    quality = grammar_issues(compressed)
    missing_facts = sorted(original_facts - compressed_facts)
    missing_states = sorted(original_states - compressed_states)
    missing_events = sorted(original_events - compressed_events)
    missing_risks = sorted(original_risks - compressed_risks)
    return {
        "passed": not missing_facts and not missing_states and not missing_events and not missing_risks and not quality,
        "missing_protected_fact_keys": missing_facts,
        "missing_state_signatures": missing_states,
        "missing_event_signatures": missing_events,
        "missing_risk_keys": missing_risks,
        "surface_quality_issues": quality,
        "original_fact_keys": sorted(original_facts),
        "compressed_fact_keys": sorted(compressed_facts),
        "original_state_signatures": sorted(original_states),
        "compressed_state_signatures": sorted(compressed_states),
        "original_event_signatures": sorted(original_events),
        "compressed_event_signatures": sorted(compressed_events),
    }


def analyze_text(text: str) -> dict:
    sections = parse_sections(text)
    sentences = split_sentences(text)
    counts = Counter(sentence_key(sentence) for sentence in sentences)
    exact_dupes = [{"sentence": sentence, "count": counts[sentence_key(sentence)]} for sentence in sentences if counts[sentence_key(sentence)] > 1]
    return {
        "tokens": count_tokens(text),
        "sentences": len(sentences),
        "sections": len(sections),
        "context_sections": sum(1 for section in sections if section.kind == "context"),
        "instruction_sections": sum(1 for section in sections if section.kind == "instruction"),
        "variable_sections": sum(1 for section in sections if section.kind == "variable"),
        "protected_facts_count": len(protected_facts(text)),
        "risk_markers": sorted(risk_markers(text)),
        "state_signatures": sorted(state_signatures(text)),
        "event_signatures": sorted(event_signatures(text)),
        "surface_quality_issues": grammar_issues(text),
        "exact_duplicates": exact_dupes[:10],
    }


def protected_facts(text: str) -> set[str]:
    patterns = [
        r"\bhttps?://[^\s\])}>]+",
        r"\b[\w.-]+@[\w.-]+\.\w+\b",
        r"\b[A-Z]{2,}-[A-Z0-9-]+\b",
        r"\b[A-Z]+-[0-9A-Z-]+\b",
        r"\b[a-z]{2}(?:-[a-z]+)+-\d+\b",
        r"\b[a-z][a-z0-9]+(?:_[a-z0-9]+)+\b",
        r"\$\d+(?:,\d{3})*(?:\.\d+)?",
        r"\b\d+(?:\.\d+)?%",
        r"\b\d+(?:\.\d+)?\s*percent\b",
        rf"\b{NUMBER_WORD_RE}\s*percent\b",
        r"\b\d+(?:\.\d+)?\s*(?:ms|milliseconds|seconds|minutes|hours|days)\b",
        rf"\b{NUMBER_WORD_RE}\s*(?:ms|milliseconds|seconds|minutes|hours|days)\b",
        r"\b\d{4}-\d{2}-\d{2}\b",
        r"\b\d{1,2}/\d{1,2}/\d{2,4}\b",
        r"\b\d{1,2}:\d{2}\s*(?:AM|PM)\b",
        r"\b(?:CUSIP|ISIN)\s+[A-Z0-9]+\b",
        r"\b(?:10-K|10-Q|T\+2|BB\+|Baa2|A/R|A/P|P&L|X-chromosome|X-inactivation|T-cell|B-cell|p53|IL-6|TNF-alpha)\b",
        r"__PROTECTED_\d+__",
    ]
    found: set[str] = set()
    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.I):
            value = match.group(0).strip(".,;:!?")
            if parse_number_words(value) is not None:
                continue
            found.add(value)
    return found


def canonical_fact_keys(text: str) -> set[str]:
    return {canonical_fact_key(fact) for fact in protected_facts(text)}


def canonical_fact_key(value: str) -> str:
    raw = value.strip()
    low = raw.lower().replace(",", "")
    percent = re.fullmatch(rf"(\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*(?:%|percent)", low)
    if percent:
        return "percent:" + normalize_number_text(percent.group(1))
    measure = re.fullmatch(rf"(\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*(ms|milliseconds)", low)
    if measure:
        return "measure:" + normalize_number_text(measure.group(1)) + ":ms"
    duration = re.fullmatch(rf"(\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*(seconds?|minutes?|hours?|days?)", low)
    if duration:
        unit = duration.group(2)
        unit = "second" if unit.startswith("second") else "minute" if unit.startswith("minute") else "hour" if unit.startswith("hour") else "day"
        return "duration:" + normalize_number_text(duration.group(1)) + ":" + unit
    return "raw:" + raw


def identity_fact_keys(text: str) -> set[str]:
    return {key for key in canonical_fact_keys(text) if key.startswith("raw:") and re.search(r"[@_\-/]|\b[A-Z]{2,}\b|\d", key[4:])}


def normalize_number_text(text: str) -> str:
    parsed = parse_number_words(text)
    if parsed is not None:
        return str(parsed)
    return text.replace(",", "").strip()


def parse_number_words(text: str) -> int | None:
    parts = [part for part in re.split(r"[-\s]+", text.lower().strip()) if part]
    if not parts or any(part not in NUMBER_WORDS for part in parts):
        return None
    total = 0
    current = 0
    for part in parts:
        value = NUMBER_WORDS[part]
        if part == "hundred":
            current = max(1, current) * 100
        elif part == "thousand":
            total += max(1, current) * 1000
            current = 0
        else:
            current += value
    return total + current


def state_signatures(text: str) -> set[str]:
    low = text.lower()
    states: set[str] = set()
    for word in STATE_WORDS:
        if word in low:
            if re.search(rf"\bnot\s+{re.escape(word)}\b", low):
                states.add("not_" + word.replace("-", "_"))
            else:
                states.add(word.replace("-", "_"))
    if re.search(r"\bnot\s+deleted\b|\bno\b[^.!?;:]{0,80}\bdeleted\b", low):
        states.add("not_deleted")
    if re.search(r"\bnot\s+offline\b|\bno\b[^.!?;:]{0,80}\boffline\b", low):
        states.add("not_offline")
    return states


EVENT_STATUS_PHRASES = {
    "is inactive": "inactive",
    "is active": "active",
    "is degraded": "degraded",
    "is read-only": "read_only",
    "status is unavailable": "unavailable",
    "is unavailable": "unavailable",
    "is not offline": "not_offline",
    "is not disabled": "not_disabled",
    "is not deleted": "not_deleted",
    "still exists": "exists",
    "is pending": "pending",
    "is not approved": "not_approved",
    "is stale": "stale",
    "is locked": "locked",
    "is not ready": "not_ready",
    "is blocked": "blocked",
    "was retained": "retained",
    "were retained": "retained",
    "was not deleted": "not_deleted",
    "were not deleted": "not_deleted",
    "was not migrated": "not_migrated",
    "were not migrated": "not_migrated",
    "was migrated": "migrated",
    "were migrated": "migrated",
}


def event_signatures(text: str) -> set[str]:
    signatures: set[str] = set()
    for sentence in split_sentences(text):
        raw = sentence.strip().strip(".")
        if not raw:
            continue
        low = raw.lower()
        list_signatures = _list_event_signatures(raw)
        signatures.update(list_signatures)

        subject = _subject_before_event(raw, r"\b(?:started|began)\b")
        if subject:
            for value in _event_values(raw):
                if re.search(r"\b(started|began)\b", low):
                    signatures.add(f"event::{subject}::started::{value}")

        for verb in ["reached", "paused"]:
            subject = _subject_before_event(raw, rf"\b{verb}\b")
            if subject and re.search(rf"\b{verb}\b", low):
                for value in _event_values(raw):
                    signatures.add(f"event::{subject}::{verb}::{value}")

        for verb in ["decreased", "increased", "dropped", "improved"]:
            subject = _subject_before_event(raw, rf"\b{verb}\b")
            if not subject or not re.search(rf"\b{verb}\b", low):
                continue
            values = _event_values(raw)
            if len(values) >= 2:
                signatures.add(f"event::{subject}::{verb}::{values[0]}->{values[1]}")

        if re.search(r"\bfailed validation\b|\bstill fails validation\b", low):
            subject = _subject_before_event(raw, r"\b(?:failed validation|still fails validation)\b")
            if subject:
                signatures.add(f"event::{subject}::failed_validation")

        if "excluded from migration" in low:
            subject = re.sub(r"^the\s+", "", raw[:low.find("excluded from migration")].strip(), flags=re.I)
            subject = re.sub(r"\s+(is|are|was|were)$", "", subject, flags=re.I)
            subject = re.sub(r"\s+note pool$", "", subject, flags=re.I)
            if subject:
                signatures.add(f"event::note_pool:{normalize_text(subject)}::excluded")

        if not list_signatures:
            status_hits = [(low.find(phrase), phrase, event) for phrase, event in EVENT_STATUS_PHRASES.items() if phrase in low]
            status_hits = [(pos, phrase, event) for pos, phrase, event in status_hits if pos >= 0]
            if status_hits:
                first_pos = min(pos for pos, _, _ in status_hits)
                subject_text = raw[:first_pos].strip(" ,.;:")
                subject_text = re.sub(r"^(the|a|an)\s+", "", subject_text, flags=re.I)
                subject = normalize_text(subject_text)
                if subject:
                    for _, _, event in status_hits:
                        signatures.add(f"event::{subject}::{event}")
    return signatures


def _list_event_signatures(sentence: str) -> set[str]:
    signatures: set[str] = set()
    list_frames = {
        "Affected cohorts": ("affected", "cohort"),
        "Affected cells": ("affected", "cell"),
        "Affected airports": ("affected", "airport"),
        "Affected gates": ("affected", "gate"),
        "Operational flights": ("operational", "flight"),
        "Recovered passenger baggage": ("recovered", "passenger_baggage"),
        "Recovered baggage IDs": ("recovered", "baggage"),
        "Healthy biomarkers": ("healthy", "biomarker"),
        "Online services": ("online", "service"),
        "Active drugs": ("active", "drug"),
        "Approved findings": ("approved", "finding"),
        "Excluded note pools": ("excluded", "note_pool"),
    }
    for prefix, (event, kind) in list_frames.items():
        if not sentence.startswith(prefix + ":"):
            continue
        for item in _split_items(sentence.split(":", 1)[1].strip(" .")):
            signatures.add(f"event::{kind}:{normalize_text(item)}::{event}")

    suffix = re.match(r"^(?P<items>.+?)\s+routing tables were migrated[.]?$", sentence, re.I)
    if suffix:
        for item in _split_items(suffix.group("items")):
            signatures.add(f"event::routing_table:{normalize_text(item)}::migrated")

    simple_patterns = [
        (r"^Cohort\s+(?P<item>.+?)\s+was affected", "cohort", "affected"),
        (r"^Cell\s+(?P<item>.+?)\s+was affected", "cell", "affected"),
        (r"^Airport\s+(?P<item>.+?)\s+was affected", "airport", "affected"),
        (r"^Gate\s+(?P<item>.+?)\s+was affected", "gate", "affected"),
        (r"^Flight\s+(?P<item>.+?)\s+is operational", "flight", "operational"),
        (r"^Passenger\s+(?P<item>.+?)\s+baggage was recovered", "passenger_baggage", "recovered"),
        (r"^Baggage\s+(?P<item>.+?)\s+was recovered", "baggage", "recovered"),
        (r"^Biomarker\s+(?P<item>.+?)\s+(?:status is healthy|is healthy)", "biomarker", "healthy"),
        (r"^Service\s+(?P<item>.+?)\s+is online", "service", "online"),
        (r"^Drug\s+(?P<item>.+?)\s+is active", "drug", "active"),
        (r"^Approved\s+(?P<item>.+?)$", "finding", "approved"),
        (r"^(?P<item>Zone-[A-Z0-9-]+)\s+routing tables were migrated", "routing_table", "migrated"),
        (r"^(?P<item>Class-[A-Z0-9-]+)\s+seating records were migrated", "seating_record", "migrated"),
        (r"^(?P<item>Class-[A-Z0-9-]+)\s+seating records were not migrated", "seating_record", "not_migrated"),
    ]
    for pattern, kind, event in simple_patterns:
        match = re.match(pattern, sentence.strip(), re.I)
        if match:
            signatures.add(f"event::{kind}:{normalize_text(match.group('item'))}::{event}")
    return signatures


def _subject_before_event(sentence: str, event_pattern: str) -> str | None:
    match = re.search(event_pattern, sentence, flags=re.I)
    if not match:
        return None
    subject = sentence[:match.start()].strip(" ,.;:")
    subject = re.sub(r"^(the|a|an)\s+", "", subject, flags=re.I)
    return normalize_text(subject) if subject else None


def _event_values(sentence: str) -> list[str]:
    values: list[str] = []
    value_pattern = (
        rf"__PROTECTED_\d+__|"
        rf"\b\d{{4}}-\d{{2}}-\d{{2}}\b|"
        rf"(?:\b(?:\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*%|\b(?:\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*percent\b)|"
        rf"\b(?:\d+(?:\.\d+)?|{NUMBER_WORD_RE})\s*(?:ms|milliseconds|seconds|minutes|hours|days)\b"
    )
    for match in re.finditer(value_pattern, sentence, flags=re.I):
        key = canonical_fact_key(match.group(0))
        if key not in values:
            values.append(key)
    return sorted(set(values), key=values.index)


def _split_items(text: str) -> list[str]:
    items: list[str] = []
    for item in re.split(r",\s*|\s+and\s+|\s+or\s+", text):
        cleaned = re.sub(r"^(and|or)\s+", "", item.strip(" ."), flags=re.I)
        if cleaned:
            items.append(cleaned)
    return items


def risk_markers(text: str) -> set[str]:
    low = text.lower()
    return {marker for marker in RISK_MARKERS if marker in low}


def risk_keys(text: str) -> set[str]:
    return {"risk:" + marker for marker in risk_markers(text)}


def grammar_issues(text: str) -> list[str]:
    issues: list[str] = []
    if re.search(r"\s+[,.!?;:]", text):
        issues.append("broken_punctuation")
    if re.search(r"\bnot\s+[A-Za-z0-9_-]+\s+or\s+[A-Za-z0-9_-]+\b", text, re.I):
        issues.append("ambiguous_not_or")
    if "PREFACE: PREFACE" in text:
        issues.append("duplicated_preface_label")
    return sorted(set(issues))


def lexical_similarity(a: str, b: str) -> float:
    a_tokens = set(re.findall(r"[A-Za-z0-9$%@./:+-]+", a.lower()))
    b_tokens = set(re.findall(r"[A-Za-z0-9$%@./:+-]+", b.lower()))
    jaccard = len(a_tokens & b_tokens) / max(1, len(a_tokens | b_tokens))
    sequence = SequenceMatcher(None, normalize_text(a), normalize_text(b)).ratio()
    fact_bonus = 0.1 if canonical_fact_keys(a) and canonical_fact_keys(a) == canonical_fact_keys(b) else 0.0
    return min(1.0, 0.6 * jaccard + 0.4 * sequence + fact_bonus)


def normalize_text(text: str) -> str:
    lowered = text.lower()
    lowered = _canonicalize_number_word_units(lowered)
    return re.sub(r"[^a-z0-9$%@./:+-]+", " ", lowered).strip()


def _canonicalize_number_word_units(text: str) -> str:
    unit_pattern = rf"\b({NUMBER_WORD_RE})\s*(percent|ms|milliseconds|seconds|minutes|hours|days)\b"

    def replace_unit(match: re.Match) -> str:
        number = parse_number_words(match.group(1))
        if number is None:
            return match.group(0)
        unit = match.group(2)
        if unit == "percent":
            return f"{number}%"
        unit = "ms" if unit == "milliseconds" else unit
        return f"{number} {unit}"

    text = re.sub(unit_pattern, replace_unit, text, flags=re.I)
    text = re.sub(r"(?<=[a-z])-(?=[a-z])", " ", text)
    text = re.sub(r"\b(were|was)\s+migrated\s+successfully\b", r"\1 migrated", text, flags=re.I)
    text = re.sub(r"\b(\d+(?:\.\d+)?)\s+percent\b", r"\1%", text, flags=re.I)
    text = re.sub(rf"\b({NUMBER_WORD_RE})\b", lambda match: str(parse_number_words(match.group(1))) if parse_number_words(match.group(1)) is not None else match.group(0), text, flags=re.I)
    return text


def sentence_key(text: str) -> str:
    return normalize_text(text)


def choose_keeper_index(sentences: list[str], i: int, j: int) -> tuple[int, int]:
    # Prefer the shorter sentence if it preserves the same facts; otherwise keep the earlier one.
    if canonical_fact_keys(sentences[i]) == canonical_fact_keys(sentences[j]):
        return (i, j) if count_tokens(sentences[i]) <= count_tokens(sentences[j]) else (j, i)
    return i, j


def join_list(items: list[str]) -> str:
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return ", ".join(items[:-1]) + f", and {items[-1]}"


def join_or_list(items: list[str]) -> str:
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} or {items[1]}"
    return ", ".join(items[:-1]) + f", or {items[-1]}"


def join_predicates(predicates: list[str]) -> str:
    if len(predicates) == 1:
        return predicates[0]
    if len(predicates) == 2:
        return f"{predicates[0]} and {predicates[1]}"
    return ", ".join(predicates[:-1]) + f", and {predicates[-1]}"


def choose_final_action(before: dict, after: dict, accepted: bool) -> str:
    if not accepted:
        return "send_original_to_next_layer"
    if before["tokens"] == after["tokens"]:
        return "no_change"
    return "use_cheap_compressed_prompt"


def run_self_checks() -> list[dict]:
    checks = [
        ("Database write latency increased from 12 ms to 28 ms.", "Database write latency increased from twelve ms to twenty-eight ms.", True),
        ("The rollout paused at 83%.", "The rollout paused at eighty-three percent.", True),
        ("Region us-east-1 was affected.", "Region us-west-2 was affected.", False),
        ("Service CACHE-WARMER is degraded.", "Service CACHE-WARMER is not offline.", False),
        ("Ledger snapshot LS-9004 was retained.", "Ledger snapshot LS-9004 was not deleted.", False),
    ]
    failures: list[dict] = []
    for a, b, expected in checks:
        ok, reasons = can_remove_sentence(a, b)
        score = lexical_similarity(a, b)
        if canonical_fact_keys(a) and canonical_fact_keys(a) == canonical_fact_keys(b):
            score = max(score, 0.95)
        actual = ok and score > 0.75
        if actual != expected:
            failures.append({"a": a, "b": b, "expected": expected, "actual": actual, "reasons": reasons})
    return failures
